package com.skcomms.dev.api.common.constants;


public class HttpHeaderKey
{
    private HttpHeaderKey(){}

    public static final String HTTP_HEADER_AUTHORIZATION="Authorization";
    public static final String HTTP_HEADER_SERVICE="Service";

}
