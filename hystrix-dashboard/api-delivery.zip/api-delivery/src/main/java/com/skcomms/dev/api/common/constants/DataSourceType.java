package com.skcomms.dev.api.common.constants;

public enum DataSourceType {
		MASTER, SLAVE;
}
